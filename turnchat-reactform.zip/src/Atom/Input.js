// import React, { useState } from "react";
// import styled from "styled-components";

// const StyledInput = styled.input`
//   width: 100%;
//   border: none;
//   outline: none;
//   border-bottom: 2px solid ${(props) => props.theme.colors.grayTwo};
//   background-color: ${(props) => props.theme.colors.grayOne};
// `;

// function Input({ initialValue = "", placeholder = "", fontSize = 16 }) {
//   const [InputValue, setInputValue] = useState(initialValue);

//   return (
//     <>
//       <StyledInput value={initialValue} placeholder={placeholder}></StyledInput>
//     </>
//   );
// }

// export default Input;
